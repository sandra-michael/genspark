package auth

import "fmt"

func Authenticate() {
	fmt.Println("authenticating user")
}
