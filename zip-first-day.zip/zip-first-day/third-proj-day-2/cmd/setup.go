package main

import "fmt"

func setup() {
	fmt.Println("Setting up ...................")
}
