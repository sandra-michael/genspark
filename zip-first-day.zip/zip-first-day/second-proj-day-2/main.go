package main

import "second-proj-day-2/user"

func main() {
	user.AddToDb("san")
}
