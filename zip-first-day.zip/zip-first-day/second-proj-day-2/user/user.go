package user

import "second-proj-day-2/auth"

var GlobalName = ""

func AddToDb(dbName) {
	name = dbName
	auth.Authenticate()
}
