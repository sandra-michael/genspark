package stringops

import "strings"

func toUpperCase(s string) string {
	return strings.ToUpper(s)
}
