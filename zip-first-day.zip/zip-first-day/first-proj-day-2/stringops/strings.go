package stringops

func ReverseAndUppercase(s1, s2 string) string {
	return reverseString(toUpperCase(s1))

	//reverseString(s1)
}
